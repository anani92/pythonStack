import parent

print(locals())
